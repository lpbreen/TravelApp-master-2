//
//  NTViewController.swift
//  TApp
//
//  Created by Liam Breen on 4/28/18.
//  Copyright © 2018 Liam Breen. All rights reserved.
//

import UIKit
import SnapKit

protocol TripDelegate {
    func makeNewTrip(trip: Trip)
}

class NTViewController: UIViewController, SentFromDelegate {
    
    func sentFrom(VC: UIViewController) {
        self.VC = VC
    }
    
    var VC: UIViewController!
    var tripToSave: Trip!
    var slLabel: UILabel!
    var slTextField: UITextField!
    var sdLabel: UILabel!
    var elLabel: UILabel!
    var elTextField: UITextField!
    var edLabel: UILabel!
    var hotelLabel: UILabel!
    var hotelTextField: UITextField!
    var saveButton: UIButton!
    var dButton: UIButton!
    
    var sdPicker: UIDatePicker!
    var edPicker: UIDatePicker!
    
    var delegate: TripDelegate!
    
    var proportionStackView: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = UIColor(red: 52/255.0, green: 187/255.0, blue: 255/255.0, alpha: 1)
        title = "New Trip"
        
        
        slLabel = UILabel()
        slLabel.text = "Start Location"
        view.addSubview(slLabel)
        
        slTextField = UITextField()
        slTextField.placeholder = "Insert text"
        slTextField.layer.borderWidth = 1
        slTextField.layer.cornerRadius = 6
        view.addSubview(slTextField)
        
        sdLabel = UILabel()
        sdLabel.text = "Start Date"
        view.addSubview(sdLabel)
        
        elLabel = UILabel()
        elLabel.text = "End Location"
        view.addSubview(elLabel)
        
        elTextField = UITextField()
        elTextField.placeholder = "Insert text"
        elTextField.layer.borderWidth = 1
        elTextField.layer.cornerRadius = 6
        view.addSubview(elTextField)
        
        edLabel = UILabel()
        edLabel.text = "End Date"
        view.addSubview(edLabel)
        
        hotelLabel = UILabel()
        hotelLabel.text = "Hotel"
        view.addSubview(hotelLabel)
        
        hotelTextField = UITextField()
        hotelTextField.placeholder = "Insert text"
        hotelTextField.layer.borderWidth = 1
        hotelTextField.layer.cornerRadius = 6
        view.addSubview(hotelTextField)
        
        saveButton = UIButton()
        saveButton.setTitle("Save", for: .normal)
        //saveButton.backgroundColor = .yellow
        saveButton.setTitleColor(.white, for: .normal)
        saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 60)
        saveButton.layer.cornerRadius = 6
        saveButton.addTarget(self, action: #selector(saveButtonPressed), for: .touchUpInside)
        view.addSubview(saveButton)
        
        dButton = UIButton()
        dButton.setTitle("Cancel", for: .normal)
        //saveButton.backgroundColor = .yellow
        dButton.setTitleColor(.white, for: .normal)
        dButton.titleLabel?.font = UIFont.systemFont(ofSize: 30)
        dButton.layer.cornerRadius = 6
        dButton.addTarget(self, action: #selector(dButtonPressed), for: .touchUpInside)
        view.addSubview(dButton)
        
        sdPicker = UIDatePicker(frame: CGRect(x: 110, y: 75, width: 300, height: 60))
        sdPicker.datePickerMode = .date
        view.addSubview(sdPicker)
        
        edPicker = UIDatePicker(frame: CGRect(x: 110, y: 150, width: 300, height: 60))
        edPicker.datePickerMode = .date
        view.addSubview(edPicker)
        
            
        setupConstraints()
    }
    
    func setupConstraints() {
        slLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(24)
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(40)
        }
        
        sdLabel.snp.makeConstraints { make in
            make.leading.equalTo(slLabel.snp.leading)
            make.top.equalTo(slLabel.snp.bottom).offset(16)
        }
        
        elLabel.snp.makeConstraints { make in
            make.leading.equalTo(slLabel.snp.leading)
            make.top.equalTo(sdLabel.snp.bottom).offset(16)
        }
        
        edLabel.snp.makeConstraints { make in
            make.leading.equalTo(slLabel.snp.leading)
            make.top.equalTo(elLabel.snp.bottom).offset(16)
        }
        
        hotelLabel.snp.makeConstraints { make in
            make.leading.equalTo(slLabel.snp.leading)
            make.top.equalTo(edLabel.snp.bottom).offset(16)
        }
        
        slTextField.snp.makeConstraints { make in
            make.leading.equalTo(slLabel.snp.trailing).offset(16)
            make.centerY.equalTo(slLabel.snp.centerY)
        }
        
        
        
        elTextField.snp.makeConstraints { make in
            make.leading.equalTo(elLabel.snp.trailing).offset(16)
            make.centerY.equalTo(elLabel.snp.centerY)
        }
        
       
        hotelTextField.snp.makeConstraints { make in
            make.leading.equalTo(hotelLabel.snp.trailing).offset(16)
            make.centerY.equalTo(hotelLabel.snp.centerY)
        }
        
        saveButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(dButton.snp.top).offset(-8)
        }
        
        dButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-80)
        }
        
    }
    
    @objc func saveButtonPressed(sender: UIButton) {
        let trip = Trip(startLocation: slTextField.text!, endLocation: elTextField.text!, startDate: sdPicker.date, endDate: edPicker.date, hotel: hotelTextField.text!)
        
        delegate?.makeNewTrip(trip: trip)
        dismiss(animated: true, completion: nil)
    }
    
    @objc func dButtonPressed(sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    func printTrip(trip: Trip) {
        print("sl: \(trip.startLocation)")
    }
    
}
