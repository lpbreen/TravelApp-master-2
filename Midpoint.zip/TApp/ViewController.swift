//
//  ViewController.swift
//  TApp
//
//  Created by Liam Breen on 4/26/18.
//  Copyright © 2018 Liam Breen. All rights reserved.
//

import UIKit

protocol SentFromDelegate {
    func sentFrom(VC: UIViewController)
}

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, TripDelegate {
    func makeNewTrip(trip: Trip) {
        Trips.append(trip)
        setupCollectionView()
    }
    
    
    var collectionView: UICollectionView!
    let nicecolor = UIColor(red: 52/255.0, green: 187/255.0, blue: 255/255.0, alpha: 1)
    let cellReuseIdentifier = "cellReuse"
    
    var delegate: SentFromDelegate!
    
    var Trips: [Trip] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       self.navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "+",
            style: .done,
            target: self,
            action: #selector(rightButtonPressed)
        )
        
        let font = UIFont.systemFont(ofSize: 30)
        navigationItem.rightBarButtonItem!.setTitleTextAttributes([NSAttributedStringKey(rawValue: NSAttributedStringKey.font.rawValue): font], for: .normal)
        
        navigationItem.rightBarButtonItem!.setTitleTextAttributes([NSAttributedStringKey(rawValue: NSAttributedStringKey.font.rawValue): font], for: .selected)
        
        view.backgroundColor = nicecolor
        self.title = "My Trips"
        
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 4)
        
        collectionView = UICollectionView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height), collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.backgroundColor = nicecolor
        
        collectionView.register(TripCollectionViewCell.self, forCellWithReuseIdentifier: cellReuseIdentifier)
        
        view.addSubview(collectionView)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellReuseIdentifier, for: indexPath) as! TripCollectionViewCell
        
        cell.sdLabel.text = String(describing: Trips[indexPath.row].startDate)
        cell.edLabel.text = String(describing: Trips[indexPath.row].endDate)
        cell.slLabel.text = Trips[indexPath.row].startLocation
        cell.elLabel.text = Trips[indexPath.row].endLocation
        cell.hLabel.text = Trips[indexPath.row].hotel
        
        cell.setNeedsUpdateConstraints()
            
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Trips.count
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat(((collectionView.frame.size.width / 2) - 10)*2), height: CGFloat(164))
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let editVC = EditTripViewController()
        navigationController?.pushViewController(editVC, animated: true)
    }
    
    @objc func rightButtonPressed(sender: UIButton) {
        let newVC = NTViewController()
        newVC.delegate = self
        present(newVC, animated: true, completion: nil)
    }
    
    func setupCollectionView () {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 4)
        
        collectionView = UICollectionView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height), collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.backgroundColor = nicecolor
        
        collectionView.register(TripCollectionViewCell.self, forCellWithReuseIdentifier: cellReuseIdentifier)
        
        view.addSubview(collectionView)
        collectionView.reloadData()
    }
    
}

