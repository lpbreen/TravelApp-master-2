//
//  EditTripViewController.swift
//  TApp
//
//  Created by Liam Breen on 4/28/18.
//  Copyright © 2018 Liam Breen. All rights reserved.
//

import UIKit
import SnapKit

class EditTripViewController: UIViewController {
    
    var calButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = UIColor(red: 52/255.0, green: 187/255.0, blue: 255/255.0, alpha: 1)
        
        calButton = UIButton()
        calButton.setTitle("Calendar", for: .normal)
        //saveButton.backgroundColor = .yellow
        calButton.setTitleColor(.white, for: .normal)
        calButton.titleLabel?.font = UIFont.systemFont(ofSize: 60)
        calButton.layer.cornerRadius = 6
        calButton.addTarget(self, action: #selector(calButtonPressed), for: .touchUpInside)
        view.addSubview(calButton)
        setupConstraints()
    }
    
    @objc func calButtonPressed() {
        navigationController?.pushViewController(CalendarViewController(), animated: true)
    }
    
    func setupConstraints() {
        calButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
        }
    }
}
