//
//  Trip.swift
//  TApp
//
//  Created by Liam Breen on 4/26/18.
//  Copyright © 2018 Liam Breen. All rights reserved.
//

import Foundation

class Trip {
    
    var startLocation: String
    var endLocation: String
    var startDate: Date
    var endDate: Date
    var hotel: String
    
    init(startLocation: String, endLocation: String, startDate: Date, endDate: Date, hotel: String) {
        self.startLocation = startLocation
        self.endLocation = endLocation
        self.startDate = startDate
        self.endDate = endDate
        self.hotel = hotel
    }
    
}
